#
# Read and write files using the built-in Python file methods
# LinkedIn Learning Python course by Joe Marini
#


def main():  
    # Open a file for writing and create it if it doesn't exist
    #myfile = open("bakkara.txt", "w+")

    
    # Open the file for appending text to the end
    #myfile = open("bakkara.txt", "a+")

    # write some lines of data to the file
    #for i in range(10,20):
    #    myfile.write("This is line of text number {}\n".format(i))
    
    # close the file when done
    #myfile.close()
    
    # Open the file back up and read the contents
    myfile = open("bakkara.txt", "r")
    if myfile.mode =='r':
        #content = myfile.read()
        #print(content)
        f1 =myfile.readlines()
        for i in (f1):
            print (i)

if __name__ == "__main__":
    main()
